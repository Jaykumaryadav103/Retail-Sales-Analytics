"""01_data_cleaning.py - validate and clean the synthetic dataset."""
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
RAW = BASE / "data" / "raw_sales_data.csv"
OUT = BASE / "data" / "cleaned_sales_data.csv"

df = pd.read_csv(RAW)
print("Raw shape:", df.shape)
print("Duplicate Order_IDs:", df["Order_ID"].duplicated().sum())

df = df.drop_duplicates(subset=["Order_ID"]).copy()

text_cols = ["Region","State","City","Customer_Name","Customer_Segment",
             "Product_Name","Category","Subcategory","Payment_Mode","Order_Status"]
for col in text_cols:
    df[col] = df[col].fillna("").astype(str).str.strip()

for col in ["Region","State","City","Product_Name"]:
    df[col] = df[col].str.title()

df["Customer_Segment"] = df["Customer_Segment"].replace("", "Unknown")
df["Payment_Mode"] = df["Payment_Mode"].replace("", "Unknown")

for col in ["Quantity","Unit_Price","Discount","Sales","Cost","Profit"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")

df["Profit"] = (df["Sales"] - df["Cost"]).round(2)
df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")
df["Order_Month"] = df["Order_Date"].dt.to_period("M").astype(str)

df["Net_Sales"] = df["Sales"].where(~df["Order_Status"].isin(["Cancelled","Returned"]), 0)
df["Net_Profit"] = df["Profit"].where(~df["Order_Status"].isin(["Cancelled","Returned"]), 0)
df["Profit_Margin"] = (df["Net_Profit"] / df["Net_Sales"].mask(df["Net_Sales"].eq(0))).fillna(0.0)

print("\nData quality summary")
print("Rows after cleaning:", len(df))
print("Duplicate Order_IDs:", df["Order_ID"].duplicated().sum())
print("Unknown Customer Segment:", (df["Customer_Segment"] == "Unknown").sum())
print("Unknown Payment Mode:", (df["Payment_Mode"] == "Unknown").sum())
print("Invalid Discount:", ((df["Discount"] < 0) | (df["Discount"] > 0.25)).sum())
print("Profit reconciliation exceptions:", ((df["Profit"] - (df["Sales"] - df["Cost"])).abs() > 0.01).sum())

df.to_csv(OUT, index=False)
print("\nSaved:", OUT)
