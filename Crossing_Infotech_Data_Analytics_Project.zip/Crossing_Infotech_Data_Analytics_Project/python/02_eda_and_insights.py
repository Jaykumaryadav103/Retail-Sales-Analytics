"""02_eda_and_insights.py - create recruiter-friendly charts."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
df = pd.read_csv(BASE / "data" / "cleaned_sales_data.csv", parse_dates=["Order_Date"])
ASSETS = BASE / "assets"
ASSETS.mkdir(exist_ok=True)

total_sales = df["Net_Sales"].sum()
total_profit = df["Net_Profit"].sum()
aov = df["Net_Sales"].sum() / (df["Net_Sales"] > 0).sum()
margin = total_profit / total_sales

print(f"Total Net Sales: ₹{total_sales:,.0f}")
print(f"Total Net Profit: ₹{total_profit:,.0f}")
print(f"Profit Margin: {margin:.1%}")
print(f"AOV: ₹{aov:,.0f}")

monthly = df.groupby("Order_Month", as_index=False)["Net_Sales"].sum()
plt.figure(figsize=(10,5))
plt.plot(monthly["Order_Month"], monthly["Net_Sales"], marker="o")
plt.title("Monthly Net Sales Trend")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(ASSETS / "monthly_net_sales.png", dpi=160)
plt.close()

region = df.groupby("Region", as_index=False)["Net_Sales"].sum().sort_values("Net_Sales", ascending=False)
plt.figure(figsize=(9,5))
plt.bar(region["Region"], region["Net_Sales"])
plt.title("Net Sales by Region")
plt.tight_layout()
plt.savefig(ASSETS / "region_sales.png", dpi=160)
plt.close()

cat = df.groupby("Category", as_index=False).agg(Net_Sales=("Net_Sales","sum"),
                                                Net_Profit=("Net_Profit","sum"))
cat["Profit_Margin"] = cat["Net_Profit"] / cat["Net_Sales"].replace(0, pd.NA)
cat = cat.dropna().sort_values("Profit_Margin", ascending=True)
plt.figure(figsize=(10,5))
plt.barh(cat["Category"], cat["Profit_Margin"])
plt.title("Profit Margin by Category")
plt.xlabel("Profit Margin")
plt.tight_layout()
plt.savefig(ASSETS / "category_margin.png", dpi=160)
plt.close()

print("Charts written to assets/")
