-- Data-quality checks
SELECT Order_ID, COUNT(*) AS duplicate_count
FROM orders
GROUP BY Order_ID
HAVING COUNT(*) > 1;

SELECT COUNT(*) AS missing_customer_segment
FROM orders
WHERE Customer_Segment IS NULL OR TRIM(Customer_Segment) = '';

SELECT COUNT(*) AS missing_payment_mode
FROM orders
WHERE Payment_Mode IS NULL OR TRIM(Payment_Mode) = '';

SELECT COUNT(*) AS invalid_discount_rows
FROM orders
WHERE Discount < 0 OR Discount > 0.25;

SELECT COUNT(*) AS profit_mismatch_rows
FROM orders
WHERE ABS(Profit - (Sales - Cost)) > 0.01;

SELECT Order_Status,
       COUNT(*) AS orders,
       SUM(Net_Sales) AS net_sales,
       SUM(Net_Profit) AS net_profit
FROM orders
GROUP BY Order_Status;

SELECT
  SUM(CASE WHEN Order_ID IS NULL OR TRIM(Order_ID) = '' THEN 1 ELSE 0 END) AS missing_order_id,
  SUM(CASE WHEN Customer_ID IS NULL OR TRIM(Customer_ID) = '' THEN 1 ELSE 0 END) AS missing_customer_id,
  SUM(CASE WHEN Product_ID IS NULL OR TRIM(Product_ID) = '' THEN 1 ELSE 0 END) AS missing_product_id
FROM orders;
