-- Business analysis

-- Monthly trend
SELECT Order_Month,
       COUNT(*) AS Orders,
       SUM(Net_Sales) AS Net_Sales,
       SUM(Net_Profit) AS Net_Profit,
       ROUND(SUM(Net_Profit) / NULLIF(SUM(Net_Sales),0), 4) AS Profit_Margin
FROM orders
GROUP BY Order_Month
ORDER BY Order_Month;

-- Region performance
SELECT Region,
       COUNT(*) AS Orders,
       SUM(Net_Sales) AS Net_Sales,
       SUM(Net_Profit) AS Net_Profit,
       ROUND(SUM(Net_Profit) / NULLIF(SUM(Net_Sales),0), 4) AS Profit_Margin
FROM orders
GROUP BY Region
ORDER BY Net_Sales DESC;

-- Category performance
SELECT Category,
       COUNT(*) AS Orders,
       SUM(Net_Sales) AS Net_Sales,
       SUM(Net_Profit) AS Net_Profit,
       ROUND(SUM(Net_Profit) / NULLIF(SUM(Net_Sales),0), 4) AS Profit_Margin
FROM orders
GROUP BY Category
ORDER BY Net_Sales DESC;

-- Customer segment using a join
SELECT c.Customer_Segment,
       COUNT(DISTINCT o.Customer_ID) AS Customers,
       COUNT(*) AS Orders,
       SUM(o.Net_Sales) AS Net_Sales,
       SUM(o.Net_Profit) AS Net_Profit
FROM orders o
JOIN customers c ON o.Customer_ID = c.Customer_ID
GROUP BY c.Customer_Segment
ORDER BY Net_Sales DESC;

-- Top products using a join
SELECT p.Product_Name,
       p.Category,
       SUM(o.Net_Sales) AS Net_Sales,
       SUM(o.Net_Profit) AS Net_Profit,
       SUM(o.Quantity) AS Units
FROM orders o
JOIN products p ON o.Product_ID = p.Product_ID
GROUP BY p.Product_Name, p.Category
ORDER BY Net_Sales DESC
LIMIT 10;

-- Region/category matrix
SELECT Region, Category,
       SUM(Net_Sales) AS Net_Sales,
       SUM(Net_Profit) AS Net_Profit
FROM orders
GROUP BY Region, Category
ORDER BY Region, Net_Sales DESC;

-- Status mix with a window function
SELECT Order_Status,
       COUNT(*) AS Orders,
       ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS Share_Percent
FROM orders
GROUP BY Order_Status
ORDER BY Orders DESC;

-- Monthly region ranking using CTE + ROW_NUMBER
WITH monthly_region AS (
    SELECT Order_Month, Region, SUM(Net_Sales) AS Net_Sales
    FROM orders
    GROUP BY Order_Month, Region
)
SELECT Order_Month,
       Region,
       Net_Sales,
       ROW_NUMBER() OVER (PARTITION BY Order_Month ORDER BY Net_Sales DESC) AS Region_Rank
FROM monthly_region
ORDER BY Order_Month, Region_Rank;
