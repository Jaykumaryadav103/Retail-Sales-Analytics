-- KPI queries

SELECT ROUND(SUM(Net_Sales),2) AS Total_Net_Sales
FROM orders;

SELECT ROUND(SUM(Net_Profit),2) AS Total_Net_Profit
FROM orders;

SELECT ROUND(SUM(Net_Profit) / NULLIF(SUM(Net_Sales),0) * 100, 2) AS Profit_Margin_Percent
FROM orders;

SELECT ROUND(SUM(Net_Sales) / NULLIF(SUM(CASE WHEN Net_Sales > 0 THEN 1 ELSE 0 END),0), 2) AS AOV
FROM orders;

SELECT ROUND(AVG(Order_Status = 'Returned') * 100, 2) AS Returned_Order_Rate_Percent
FROM orders;

SELECT ROUND(AVG(Order_Status = 'Cancelled') * 100, 2) AS Cancelled_Order_Rate_Percent
FROM orders;

SELECT Product_Name, ROUND(SUM(Net_Profit),2) AS Net_Profit
FROM orders
GROUP BY Product_Name
ORDER BY Net_Profit DESC
LIMIT 5;

SELECT Order_ID, Product_Name, Discount, Net_Sales, Net_Profit, Profit_Margin
FROM orders
WHERE Discount >= 0.20
  AND Profit_Margin < 0.15
ORDER BY Profit_Margin ASC
LIMIT 20;
