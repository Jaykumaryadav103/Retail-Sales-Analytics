-- MySQL-compatible schema
CREATE DATABASE IF NOT EXISTS retail_analytics;
USE retail_analytics;

DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS products;

CREATE TABLE customers (
    Customer_ID VARCHAR(10) PRIMARY KEY,
    Customer_Name VARCHAR(100),
    Customer_Segment VARCHAR(30),
    Region VARCHAR(30)
);

CREATE TABLE products (
    Product_ID VARCHAR(10) PRIMARY KEY,
    Product_Name VARCHAR(100),
    Category VARCHAR(50),
    Subcategory VARCHAR(60),
    Unit_Price DECIMAL(12,2),
    Unit_Cost DECIMAL(12,2)
);

CREATE TABLE orders (
    Order_ID VARCHAR(10) PRIMARY KEY,
    Order_Date DATE,
    Region VARCHAR(30),
    State VARCHAR(50),
    City VARCHAR(50),
    Customer_ID VARCHAR(10),
    Customer_Name VARCHAR(100),
    Customer_Segment VARCHAR(30),
    Product_ID VARCHAR(10),
    Product_Name VARCHAR(100),
    Category VARCHAR(50),
    Subcategory VARCHAR(60),
    Quantity INT,
    Unit_Price DECIMAL(12,2),
    Discount DECIMAL(5,2),
    Sales DECIMAL(14,2),
    Cost DECIMAL(14,2),
    Profit DECIMAL(14,2),
    Payment_Mode VARCHAR(30),
    Order_Status VARCHAR(30),
    Order_Month VARCHAR(7),
    Net_Sales DECIMAL(14,2),
    Net_Profit DECIMAL(14,2),
    Profit_Margin DECIMAL(8,4)
);

-- Import customers_dim.csv, products_dim.csv and cleaned_sales_data.csv
-- into the three tables before running analysis queries.
