# Dashboard Layout

## Executive page
```text
┌─────────────────────────────────────────────────────────────────────┐
│ Retail Sales Analytics — Executive Dashboard                       │
├────────────┬────────────┬────────────┬────────────┬────────────┬────┤
│ Net Sales  │ Net Profit │ Margin %   │ Orders     │ Units      │AOV │
├──────────────────────────────────┬──────────────────────────────────┤
│ Monthly Net Sales Trend          │ Net Sales by Region              │
├──────────────────────────────────┼──────────────────────────────────┤
│ Net Profit by Category           │ Order Status Mix                 │
├─────────────────────────────────────────────────────────────────────┤
│ Slicers: Date | Region | Category | Customer Segment                │
└─────────────────────────────────────────────────────────────────────┘
```

## Design principles
- KPI cards at the top.
- INR format for sales/profit.
- Percentage format for margin and rates.
- Drill-down Region → State → City where useful.
- Tooltips should include Orders, Units, AOV and Margin.
- Keep data-quality visuals on a separate page.
