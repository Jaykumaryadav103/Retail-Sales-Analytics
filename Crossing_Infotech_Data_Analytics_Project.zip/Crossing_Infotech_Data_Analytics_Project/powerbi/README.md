# Power BI Dashboard Guide

## Import
1. Open Power BI Desktop.
2. Select **Get Data → Text/CSV**.
3. Import `data/cleaned_sales_data.csv`.
4. Optionally import `customers_dim.csv` and `products_dim.csv`.
5. Create relationships:
   - `Orders[Customer_ID]` → `Customers[Customer_ID]`
   - `Orders[Product_ID]` → `Products[Product_ID]`
6. Add the DAX measures from `DAX_Measures.dax`.

## Dashboard pages
### Page 1 — Executive KPI Dashboard
Cards: Net Sales, Net Profit, Profit Margin, Orders, Units, AOV.

Charts: Monthly Net Sales, Net Sales by Region, Net Profit by Category, Order Status Mix.

Slicers: Date, Region, Category, Customer Segment.

### Page 2 — Product & Category Analysis
- Top 10 products by Net Sales
- Top 10 products by Net Profit
- Category sales vs profit margin
- Discount vs profit margin

### Page 3 — Data Quality
- Duplicate count
- Unknown Customer Segment count
- Unknown Payment Mode count
- Invalid discount count
- Profit reconciliation exceptions

The repository provides the data model, DAX measures and a dashboard wireframe. A `.pbix` file is intentionally not included because Power BI Desktop is required to generate and save the native report file.
