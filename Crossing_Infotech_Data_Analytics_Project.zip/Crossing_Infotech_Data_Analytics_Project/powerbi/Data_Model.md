# Power BI Data Model

## Tables
### Orders
Order-level fact table with sales, cost, profit, quantity, dates, status, customer and product keys.

### Customers
Customer dimension with Customer_ID, Customer_Name, Customer_Segment and Region.

### Products
Product dimension with Product_ID, Product_Name, Category, Subcategory, Unit_Price and Unit_Cost.

## Relationships
`Customers[Customer_ID]` 1 → * `Orders[Customer_ID]`
`Products[Product_ID]` 1 → * `Orders[Product_ID]`

For a production model, add a dedicated Date table related to `Orders[Order_Date]`.
