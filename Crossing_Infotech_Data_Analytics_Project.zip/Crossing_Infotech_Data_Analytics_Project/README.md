# Retail Sales Analytics & KPI Reporting — Data Analytics Internship Portfolio Project

## Project headline
**End-to-End Retail Sales Analytics using Excel, SQL, Python & Power BI**

> **Portfolio note:** All data in this repository is synthetic and created for learning/portfolio purposes. It is not Crossing Infotech's internal data.

## Why this project matches the internship
| Internship requirement | Project implementation |
|---|---|
| Collect and organize datasets | `data/raw_sales_data.csv` |
| Data cleaning & validation | `python/01_data_cleaning.py`, Excel Validation Checks |
| Missing/duplicate/inconsistent values | Deliberate raw-data issues + validation queries |
| Basic SQL analysis | `sql/02_business_analysis.sql` |
| Joins, filtering, grouping, aggregation | Customer/Product dimension joins + KPI queries |
| Daily/weekly/monthly reporting | `data/monthly_kpi.csv`, Excel Monthly Report |
| Power BI dashboards | `powerbi/` model, DAX measures and layout |
| Trends, patterns and KPIs | Sales, profit, margin, AOV, units and status analysis |
| Reconciliation checks | Excel Validation Checks + SQL quality queries |
| Charts and summaries | Excel dashboard + Python charts + Power BI layout |
| Documentation | Data dictionary, project summary, interview Q&A |

## Business problem
Management wants to understand:
1. Which regions and categories generate the most net sales and profit?
2. How do monthly sales and profit change over time?
3. Which customer segments contribute the most value?
4. How do order statuses affect reported revenue?
5. Which products should be reviewed based on sales/profit performance?
6. Are there data-quality issues that could affect reporting?

## Dataset
- Base order records: **1,800**
- Extra duplicate records intentionally added to raw file: **15**
- Cleaned unique order records: **1,800**
- Reporting period: **January 2025 to March 2026**
- Currency: INR
- Synthetic geography: Indian regions/states/cities

## End-to-end workflow
**Raw data → quality checks → clean data → SQL analysis → Python EDA → Excel MIS/KPI report → Power BI dashboard → business insights**

## Main KPIs
- Total Net Sales
- Total Net Profit
- Profit Margin
- Total Orders
- Total Units
- Average Order Value (AOV: Net Sales ÷ revenue-contributing orders)
- Returned Order Rate
- Cancelled Order Rate

## Interview-ready explanation
> “I created an end-to-end retail sales analytics project using synthetic order data. I first performed data-quality checks and removed duplicate or inconsistent records. Then I used SQL for filtering, aggregation, joins and KPI analysis. In Python I used Pandas for cleaning and exploratory analysis. In Excel I prepared MIS-style monthly reporting and validation checks. Finally, I designed a Power BI dashboard around sales, profit, margin, AOV and regional/category performance. The focus was making reporting repeatable and validating the data before presenting business insights.”

## Important
Present this as a **self-initiated portfolio project aligned to the internship job description**, not as company work.
