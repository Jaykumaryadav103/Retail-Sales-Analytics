# KPI Report

| KPI | Value |
|---|---:|
| Total Orders | 1,800 |
| Revenue-Contributing Orders | 1,480 |
| Net Sales | ₹7,757,048 |
| Net Profit | ₹2,739,598 |
| Profit Margin | 35.3% |
| Units Sold | 3,483 |
| AOV | ₹5,241 |

**AOV definition:** Net Sales ÷ revenue-contributing orders (`Net_Sales > 0`).

**Reporting rule:** Net Sales and Net Profit exclude `Cancelled` and `Returned` orders.

All figures are from synthetic portfolio data.
