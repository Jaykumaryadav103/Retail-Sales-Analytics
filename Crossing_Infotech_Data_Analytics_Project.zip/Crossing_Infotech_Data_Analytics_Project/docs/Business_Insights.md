# Business Insights

This section demonstrates the style of insight a fresher could produce from a portfolio dataset.

## Overall performance
- Net sales: ₹7,757,048
- Net profit: ₹2,739,598
- Profit margin: 35.3%
- Revenue-contributing orders: 1,480
- AOV: ₹5,241

## Region analysis
The highest-sales region in this synthetic dataset is **North**. This is a descriptive result for the generated dataset only.

## Category analysis
The highest-sales category is **Electronics**, while the highest-profit category is **Electronics**.

## Monthly trend
The highest net-sales month is **2026-03** with approximately **₹744,374**.

## Order-status rule
Returned and cancelled orders are excluded from Net Sales and Net Profit in this project. The rule is documented in the README, SQL and Excel workbook.

## Interview insight pattern
Use:
**Observation → Evidence → Business implication → Next check**

Example:
> “I noticed that one category generated high sales but its profit margin was lower than some other categories. I would next check discount levels, product-level margins and return rates before recommending any action.”
