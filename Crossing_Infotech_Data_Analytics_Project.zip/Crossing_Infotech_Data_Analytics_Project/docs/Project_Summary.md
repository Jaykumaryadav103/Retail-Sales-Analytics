# Project Summary

## Objective
Build a practical analytics workflow that converts raw retail-order data into validated reporting and business insights.

## Synthetic dataset KPIs
- Cleaned orders: 1,800
- Revenue-contributing orders: 1,480
- Net sales: ₹7,757,048
- Net profit: ₹2,739,598
- Profit margin: 35.3%
- Units: 3,483
- AOV (Net Sales ÷ revenue-contributing orders): ₹5,241

## Data-quality controls
- Duplicate Order_ID detection
- Missing Customer_Segment detection
- Missing Payment_Mode detection
- Text normalization for Region, City and Product_Name
- Standardized categorical values
- Discount range check
- Profit reconciliation
- Row-count reconciliation
