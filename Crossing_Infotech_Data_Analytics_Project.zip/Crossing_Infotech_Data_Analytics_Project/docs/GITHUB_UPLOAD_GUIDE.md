# GitHub Upload Guide

## Recommended repository name
`retail-sales-analytics-excel-sql-powerbi`

## Upload using the GitHub website
1. Extract the ZIP on your computer.
2. Create a new GitHub repository with the recommended name.
3. Choose the visibility you want for your portfolio.
4. Open the repository and click **Add file → Upload files**.
5. Upload the project folder contents, not just the ZIP archive.
6. Commit the files.
7. Open `README.md` and confirm it displays correctly.

## Recommended repository description
`End-to-end retail sales analytics portfolio project using Excel, SQL, Python/Pandas and Power BI-ready reporting.`

## Do not claim
- “Worked at Crossing Infotech”
- “Crossing Infotech company project”
- “Real company dataset”

Use:
**“Self-initiated portfolio project aligned to a Data Analytics Internship job description.”**
