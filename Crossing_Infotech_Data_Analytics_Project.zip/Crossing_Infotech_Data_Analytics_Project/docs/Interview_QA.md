# Interview Q&A

## Q1. Tell me about your project.
**Answer:** I built an end-to-end retail sales analytics project using synthetic order data. I cleaned and validated the data, used SQL for business analysis, used Python and Pandas for exploratory analysis, created Excel MIS and KPI reporting, and designed a Power BI dashboard structure.

## Q2. What data-quality problems did you handle?
**Answer:** I handled duplicate order records, missing customer segment and payment mode values, inconsistent text formatting, and categorical normalization. I also added validation checks for discount ranges and profit calculations.

## Q3. Why did you exclude returned and cancelled orders from Net Sales?
**Answer:** I wanted a clearly defined business rule. Returned and cancelled orders were excluded from Net Sales and Net Profit so the main KPI represented orders that remained in the business flow. I documented the rule so the report is transparent.

## Q4. Which SQL concepts did you use?
**Answer:** SELECT, WHERE, CASE, GROUP BY, HAVING, aggregate functions, CTEs, joins and window functions such as ROW_NUMBER.

## Q5. How did you use Excel?
**Answer:** I used Excel for a structured data table, KPI calculations, monthly MIS reporting, validation checks, formulas, conditional formatting and charts.

## Q6. Why use Power BI when Excel already has charts?
**Answer:** Excel is useful for detailed tabular reporting and quick analysis. Power BI is better for interactive dashboards, slicers and reusable reporting views.

## Q7. What would you improve next?
**Answer:** I would connect Power BI to a database, add scheduled refresh, introduce a dedicated Date dimension, and expand customer and product-level analysis.
